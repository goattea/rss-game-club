Endalian Script font, made 10/4/2022
Version 1.0 - Designed by Yakmage

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Ende is free for any use for any project and is distributed with a Creative Commons CC0 “No Rights Reserved,” that means you can freely use it in commercial work and distribute adaptations, and no attribution is required. Have some fun.

To view a copy of this license, visit: https://creativecommons.org/share-your-work/public-domain/cc0/

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Hope you enjoy the font!
If you actually read this, email me your best joke at obsidiantcg@gmail.com! I'll get a real kick out of it!